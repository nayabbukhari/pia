<footer>
    <div class="row">
      <div class="col-sm-6"> <span class="footer-brand"> <img style="margin-bottom:25px;" src="img/Probatio-Large.png" width="150px" height="45px"></span>
        <p class="no-margin"> &copy; 2016 <strong>Probatio Insurance Application </strong>. ALL Rights Reserved. </p>
      </div>
      <!-- /.col --> 
    </div>
    <!-- /.row--> 
  </footer>
    
<!-- Logout confirmation -->
<div class="custom-popup width-100" id="logoutConfirm">
  <div class="padding-md">
    <h4 class="m-top-none"> Do you want to logout?</h4>
  </div>
  <div class="text-center"> <a class="btn btn-success m-right-sm" style="background: #28a878;" href="logout.php">Logout</a> <a style="background: #d44935;" class="btn btn-danger logoutConfirm_close">Cancel</a> </div>
</div>

<!-- Le javascript-->